/** Administra los productos que se van registrando en la clase de productos, del cual se mantienen conectado con la clase de Sistema.
 * 
    **/
package Clases;
import java.util.ArrayList;
import java.util.Collections;

public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {
        this.productos = new ArrayList<>();
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }
    
    public void agregarProducto(Producto p){
        productos.add(p);
    }
    
    public ArrayList<Producto> obtenerProductos(){
        return productos;
    }
    
    public Producto buscarProducto (int idProducto){
        for(Producto producto : productos){
            if(producto.getIdProducto() == idProducto){
                return producto;
            }
        }
        return null;
    }
    
    public void eliminarProducto(int idProducto)throws ProductoNoEncontrado{
        Producto producto = buscarProducto(idProducto);
        if(producto!=null){
            productos.remove(producto);
        }else{
            throw new ProductoNoEncontrado("No existe un producto con ID: "+ idProducto);
        }
    }
    
    public void actualizarProducto(Producto p)throws ProductoNoEncontrado{
        Producto producto = buscarProducto(p.getIdProducto());
        
        if(producto != null){
            producto.setNombreProducto(p.getNombreProducto());
            producto.setDescripcion(p.getDescripcion());
            producto.setPrecio(p.getPrecio());
            producto.setCantidad(p.getCantidad());
            producto.setTipo(p.getTipo());
        }else{
            throw new ProductoNoEncontrado("No existe un producto con ID: "+ p.getIdProducto());
        }
    }
    
    public void ordenarProductos(){
        Collections.sort(productos);
    }
}
