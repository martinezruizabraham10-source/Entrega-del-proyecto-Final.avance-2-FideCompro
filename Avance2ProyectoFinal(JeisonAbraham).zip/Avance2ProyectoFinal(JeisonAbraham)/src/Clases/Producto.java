
package Clases;
import java.io.Serializable;

public class Producto implements Serializable, Comparable<Producto>{
    private int idProducto;
    private String nombreProducto;
    private String descripcion;
    private double precio;
    private int cantidad;
    private String tipo;

    public Producto() {
        this.idProducto = 0;
        this.nombreProducto = "";
        this.descripcion = "";
        this.precio = 0.00;
        this.cantidad = 0;
        this.tipo = "";
    }

    public Producto(int idProducto, String nombreProducto, String descripcion, double precio, int cantidad, String tipo) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tipo = tipo;
    }
    

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
   public void reducirCantidad(int cantidad){
       this.cantidad -= cantidad;
       
   }
   
   public void aumentarCantidad(int cantidad){
       this.cantidad += cantidad;
   }
   
   @Override
    public String toString(){
        return "Producto: "+ nombreProducto;
    }
    
    @Override
    public int compareTo(Producto p){
        return this.nombreProducto.compareTo(p.getNombreProducto());
    }
    
    @Override
    public boolean equals(Object o){
        
        if (this == o){
            return true;
        }
        if (o==null|| getClass() != o.getClass()) return false;
        Producto p=(Producto)o;
        return this.idProducto == p.getIdProducto();
    }
    
    @Override
    public int hashCode(){
        return Integer.hashCode(idProducto);
    }
}
 