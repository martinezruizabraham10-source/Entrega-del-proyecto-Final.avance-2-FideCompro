
package Clases;
import java.io.Serializable;

public class Cliente implements Serializable, Comparable<Cliente> {
    private int idCliente;
    private String nombre;
    private String cedula;
    private String direccion;

    public Cliente() {
        this.idCliente = 0;
        this.nombre = "";
        this.cedula = "";
        this.direccion = "";
    }

    public Cliente(int idCliente, String nombre, String cedula, String direccion) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.cedula = cedula;
        this.direccion = direccion;
    }
    

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
     @Override
    public String toString(){
        return "Cliente: "+ nombre;
    }
    
    @Override
    public int compareTo(Cliente c){
        return this.nombre.compareTo(c.getNombre());
    }
    
     @Override
    public boolean equals(Object o){
        
        if (this == o){
            return true;
        }
        if (o==null|| getClass() != o.getClass()) return false;
        Cliente c=(Cliente)o;
        return this.idCliente == c.idCliente;
    }
    
    @Override
    public int hashCode(){
        return Integer.hashCode(idCliente);
    }
}
