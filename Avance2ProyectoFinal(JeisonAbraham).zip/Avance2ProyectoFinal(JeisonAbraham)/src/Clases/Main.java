package Clases;
/**
 
             °      ---------------------       ° 

                    Universidad Fidélitas

                Avance 2. Proyecto final (Valor 10%)
    

                         Estudiante:
                 Jeison Abraham Martínez Ruíz

                         Profesor(a):
                   Vargas Montes Mario Alberto

                        Cuatrimestre:
                       III Cuatrimestre

                        Fecha de entrega:
                           10/11/2026 

Bienvenido sea al código de creación, con respecto al entregable del avance 2 del proyecto final. Documentaré las clases de las cuales, se pueden considerar de importancia, teniendo en cuenta
* aspectos clave. Con respecto a la funcionalidad del programa, se requiere que inicie el programa en la GUI denominada "InicioSesion" ya que es ahí donde el programa corre vida.
* Y con respecto a la lectura, después que lea esto, vaya a la clase Sistema, ya que ahí se habla de los primeros puntos del sistema.
* con respecto a las demás ventanas, documentarémos lo importante como dije anteriormente.

Los paquetes se dividen en dos aspectos: Clases y GUI, ya que así mantenemos el orden entre normas, y no hay problema porque podemos importar las clases hacia las ventanas, y viceversa si fuera el caso.
**/
public class Main {

}
