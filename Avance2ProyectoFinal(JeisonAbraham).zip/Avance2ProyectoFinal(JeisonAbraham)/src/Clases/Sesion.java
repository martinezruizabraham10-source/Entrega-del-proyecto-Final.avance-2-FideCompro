
package Clases;

public class Sesion {
    private Usuario usuarioActivo;
    private boolean sesionActiva;

    public Sesion() {
        this.usuarioActivo = null;
        this.sesionActiva = false;
    }

    public Usuario getUsuarioActivo() {
        return usuarioActivo;
    }

    public void setUsuarioActivo(Usuario usuarioActivo) {
        this.usuarioActivo = usuarioActivo;
    }

    public boolean isSesionActiva() {
        return sesionActiva;
    }

    public void setSesionActiva(boolean sesionActiva) {
        this.sesionActiva = sesionActiva;
    }
    
    public void iniciarSesion(Usuario usuario){
        this.usuarioActivo= usuario;
        this.sesionActiva= true;
    }
    
    public void cerrarSesion(){
        this.usuarioActivo= null;
        this.sesionActiva= false;
    }
}
