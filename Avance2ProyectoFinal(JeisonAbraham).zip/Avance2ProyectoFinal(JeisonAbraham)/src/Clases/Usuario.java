
package Clases;
import java.io.Serializable;

public class Usuario implements Serializable, Comparable<Usuario> {
    private int idUsuario;
    private String usuario;
    private String contraseña;

    public Usuario() {
        this.idUsuario = 0;
        this.usuario = "";
        this.contraseña = "";
    }

    public Usuario(int idUsuario, String usuario, String contraseña) {
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.contraseña = contraseña;
    }
    

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    @Override
    public String toString(){
        return "Usuario: "+ usuario;
    }
    
    @Override
    public int compareTo(Usuario u){
        return this.usuario.compareTo(u.getUsuario());
    }
    
    @Override
    public boolean equals(Object o){
        
        if (this == o){
            return true;
        }
        if (o==null|| getClass() != o.getClass()) return false;
        Usuario u=(Usuario)o;
        return this.idUsuario == u.idUsuario;
    }
    
    @Override
    public int hashCode(){
        return Integer.hashCode(idUsuario);
    }
}