/**
 * La clase Sistema, es el encargado de manejar prácticamente la lógica de todo el sistema. Administrando atributos y métodos de las clases:
 * - Usuario 
 * - Clientes
 * - Productos
 * - y Factura.
 * 
 * Cada método ingresado aquí, tiene con el propósito de conectar de manera eficaz y sencilla con los GUI implementados en el prototipo del avance 1. comenzemos.

**/
package Clases;
//Se importa los paquetes util, para poner en lista tanto a los clientes, como al usuario que compartirá valor con Sistema en las ventanas.
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class Sistema {
    //Añadimos los atributos, que son parte de las demás clases, y de las cuales usarémos sus atributos y métodos.
    private final Sesion sesion;
    private final Inventario inventario;
    private final ArrayList<Cliente> listaClientes;
    private final ArrayList<Usuario> listaUsuarios;

    //Iniciamos constructor basandonos en cada atributo de clases.
    public Sistema() {
        this.sesion = new Sesion();
        this.inventario = new Inventario();
        this.listaClientes = new ArrayList<>();
        this.listaUsuarios= new ArrayList<>();
    }

    
    public Sesion getSesion() {
        return sesion;
    }

    public Inventario getInventario() {
        return inventario;
    }

    public ArrayList<Cliente> getListaClientes() {
        return listaClientes;
    }
    
    public ArrayList<Usuario> getListaUsuarios(){
        return listaUsuarios;
    }
    //Método encargado de registrar a los clientes y mostrar lo que sucede en consola.
    public void registrarCliente (Cliente c){
        listaClientes.add(c);
        
        System.out.println("[Cliente] - Registrado->->"+c.getNombre()+"\nID: "+c.getIdCliente());
    }
    
    //Muestra el usuario quien tiene acceso al sistema
    public void registrarUsuario (Usuario u){
        listaUsuarios.add(u);
        
        System.out.println("[Usuario] - Registrado ->-> "+u.getUsuario());
    }
    
    /** Registra cada producto y los muestra en consola. En la ventana AgregarProducto, se puede visualizar en la tabla los productos que uno va registrando:
     * su id, nombre, tipo, cantidad, y precio.   
    **/
    public void registrarProducto (Producto p){
        inventario.agregarProducto(p);
        
        System.out.println("[Producto] - Registrado ->-> "+p.getNombreProducto()+"\nID del producto: "+p.getIdProducto());
    }
    
    /**Encargado de buscar los clientes de acuerdo al ID, aparece en consola el id y el nombre del cliente. en la ventana, se muestra el nombre, el id, la cédula y la dirección.
     * 
    **/
    public Cliente buscarCliente (int idCliente){
        System.out.println("[Busqueda de cliente] - Buscando cliente....:");
        
        for(Cliente cliente : listaClientes){
            if(cliente.getIdCliente() == idCliente){
                
                System.out.println("[Busqueda de cliente] - Cliente encontrado: "+cliente.getNombre());
                return cliente;
            }
        }
        System.out.println("[Busqueda de cliente] - Cliente no encontrado");
        return null;
    }
    
    /**   Al igual que buscar clientes, este busca por medio del id, busca el producto, y muestra en consola el id y el nombre.
     * En ventana muestra lo que se refiere al nombre, descripción del producto, tipo de producto, precio y cantidad del producto.
    **/ 
    public Producto buscarProducto(int idProducto){
        System.out.println("[Busqueda de producto] - Buscando producto....:");
        
        Producto producto = inventario.buscarProducto(idProducto);
        if (producto != null){
            System.out.println("[Busqueda de producto] - Producto encontrado: "+ producto.getNombreProducto());
        }else{
            System.out.println("[Busqueda del producto] - Producto no encontrado");
        }
        return producto;
    }
    
    
    /**Encargado de mostrar en consola, el usuario quien está ingresando al sistema en consola, en ventana, permite que ingrese el usuario, que en este caso sería "Admin" cuya
     * contraseña es "1234". Caso contrario el usuario no sea ese, le denegará el acceso al sistema.
    **/
    public boolean iniciarSesion(String usuario, String contraseña){
        System.out.println("[Servidor] - Intento de inicio de sesion...-> "+ "-> Usuario: "+usuario);
        for (Usuario u: listaUsuarios){
            if(u.getUsuario().equals(usuario)&& u.getContraseña().equals(contraseña)){
                sesion.iniciarSesion(u);
                System.out.println("Acceso concedido!");
                return true;
            }
        }
        
        System.out.println("Acceso denegado!");
        return false;
    }
    
    /**Este método, permite que por medio del menú (una vez ya ingresado), permita al usuario salir del menú,cumpliendo así es una de las historias de usuario y dandole más dinámica 
     * al sistema.
    **/
    public void cerrarSesion(){
        sesion.cerrarSesion();
    }
    
    public void ordenarClientes(){
        Collections.sort(listaClientes);
    }
    
    public void ordenarUsuarios(){
        Collections.sort(listaUsuarios);
    }
    
    public  Factura crearFactura(Cliente c, ArrayList<DetalleFactura> detalles){
        Factura factura = new Factura();
        factura.setCliente(c);
        factura.setDetalles(detalles);
        factura.calcularTotal();
        System.out.println("\n-----Factura generada----\n");
        System.out.println("==================FACTURA==================");
        System.out.println("");
        System.out.println("Fecha de facturacion: "+ new Date());
        System.out.println("------------------------------------\n");
        System.out.println("========CLIENTE=======");
        System.out.println("Nombre: "+ c.getNombre());
        System.out.println("Num_Cedula: "+ c.getCedula());
        System.out.println("Direccion: "+ c.getDireccion()+"\n\n");
        
        System.out.println("==========DETALLES==========\n");
        for(DetalleFactura detalle : detalles){
            System.out.println("| Producto: "+detalle.getProducto().getNombreProducto()+" | Cantidad: "+ detalle.getCantidad()+" | Subtotal: "+ detalle.getSubTotal()+" Colones");
            System.out.println("------------------------------------------------");
        }
        System.out.println("\nTOTAL:"+factura.getTotal()+" Colones");
        System.out.println("====================\n");
        return factura;
    }
}
