
package Clases;

public class ProductoNoEncontrado extends Exception{
    public ProductoNoEncontrado(String mensaje){
        super(mensaje);
    }
}
