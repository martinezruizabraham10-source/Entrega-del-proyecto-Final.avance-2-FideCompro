/**Esta clase, es capaz de generar una representación fisica de una factura. Del cual lo hace en formato TXT, con toda la información de la factura, se puede ver tanto en el sistema
 * de las mismas carpetas, o en consola, intentado cumplir el punto de las historias de usuario.
    **/
package Clases;
import java.io.Serializable;
import java.io.FileWriter;
import java.io.IOException;

public class FacturaFisica implements Serializable{
    private Factura factura;

    public FacturaFisica() {
        this.factura = null;
    }

    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }
    
    public void generarTXT(){
        try{
            try (FileWriter archivo = new FileWriter("Factura_"+ factura.getIdFactura()+".txt")) {
                archivo.write("======FACTURA======\n");
                archivo.write("ID factura: " + factura.getIdFactura()+"\n");
                archivo.write("Fecha: "+ factura.getFecha()+"\n\n");
                archivo.write ("-------------CLIENTE------------\n");
                archivo.write("Nombre: "+factura.getCliente().getNombre()+"\n");
                archivo.write("Cédula: "+factura.getCliente().getCedula()+"\n");
                archivo.write("Dirección: "+factura.getCliente().getDireccion()+"\n\n");
                archivo.write("=======================================================\n");
                
                archivo.write("---------------PRODUCTOS---------------\n");
                for(DetalleFactura detalle : factura.getDetalles()){
                    archivo.write(detalle.getProducto().getNombreProducto()+" | Cantidad: "+ detalle.getCantidad()+ " | Subtotal: ₡"+detalle.getSubTotal()+"\n");
                }
                archivo.write("\nTOTAL: ₡"+factura.getTotal());
            }
        }catch (IOException e){
            System.out.println("Error al generar factura" + e.getMessage());
        }
    }
}
