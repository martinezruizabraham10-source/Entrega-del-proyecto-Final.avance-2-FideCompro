/**Esta clase es lo que permite representar una factura que va dirigida a un cliente, de lo cual, contiene:
 * - Fecha
 * - Nombre del cliente
 * - Productos a detalle y subtotal.
 * - Y el total de todo.
 * Y comparte relacion con la clase DetalleFactura.
    **/
package Clases;
import java.util.ArrayList;
import java.util.Date;
import java.io.Serializable;

public class Factura implements Serializable {
    private int idFactura;
    private Date fecha;
    private Cliente cliente;
    private ArrayList<DetalleFactura> detalles;
    private double total;

    public Factura() {
        this.idFactura = 0;
        this.fecha = new Date();
        this.cliente = null;
        this.detalles = new ArrayList<>();
        this.total = 0.00;
    }

    public int getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public ArrayList<DetalleFactura> getDetalles() {
        return detalles;
    }

    public void setDetalles(ArrayList<DetalleFactura> detalles) {
        this.detalles = detalles;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    public void agregarDetalle(DetalleFactura d){
        detalles.add(d);
    }
    
    /** Encargado de calcular el total, utilizando los subtotales de los detalles que se vayan registrando.   
    **/
    public void calcularTotal(){
        total=0;
        
        for(DetalleFactura detalle : detalles){
            total += detalle.getSubTotal();        
        }
    }
}
 