/** Encargado de tener en cuenta todos los detalles que podría contener una factura.
 * La clase conriene un método que calcula los precios del producto de acuerdo a la cantidad que se adquiera en la factura.
    **/
package Clases;
import java.io.Serializable;

public class DetalleFactura implements Serializable {
    private Producto producto;
    private int cantidad;
    private double subTotal;

    public DetalleFactura() {
        this.producto = null;
        this.cantidad = 0;
        this.subTotal = 0.00;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }
    
    public void calcularSubtotal(){
        this.subTotal= producto.getPrecio()*cantidad;
    }
}
