/**Ventana creada para realizar facturas, agregar los productos a la factura (siempre cuando exista el usuario y el producto) y la cantidad, para posteriormente mostrarlo en HTML, y
 * con la ayuda de la Clase Sistema, mostrarlo en la consola también.
    **/
package GUI;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Clases.Cliente;
import Clases.Producto;
import Clases.DetalleFactura;
import Clases.Factura;
import Clases.FacturaFisica;
import Clases.Sistema;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Jeison Abraham Martínez Ruíz.
 */
public class CrearFactura extends javax.swing.JFrame {
    private final String usuario;
    private final Sistema sistema;
    private Cliente cliente;
    private final ArrayList<DetalleFactura> detalles;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CrearFactura.class.getName());


    public CrearFactura(String usuario, Sistema sistema) {
        initComponents();
        
        this.usuario = usuario;
        this.sistema = sistema;
        
        detalles = new ArrayList<>();
        labelFecha.setText("Fecha: "+ new Date());
    }
    private static int contadorFacturas= 1;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        labelTitulo1 = new javax.swing.JLabel();
        botonFacturafísica = new javax.swing.JButton();
        labelD = new javax.swing.JLabel();
        textoID = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        botonAgregar = new javax.swing.JButton();
        labelProductos = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTablaProductos = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        labelTotal = new javax.swing.JLabel();
        labelD1 = new javax.swing.JLabel();
        labelD2 = new javax.swing.JLabel();
        textoIDProducto = new javax.swing.JTextField();
        textocantidad = new javax.swing.JTextField();
        labelFecha = new javax.swing.JLabel();
        botonVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(0, 102, 255));

        labelTitulo1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        labelTitulo1.setForeground(new java.awt.Color(255, 255, 255));
        labelTitulo1.setText("Crear factura");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(354, 354, 354)
                .addComponent(labelTitulo1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(labelTitulo1)
                .addGap(25, 25, 25))
        );

        botonFacturafísica.setBackground(new java.awt.Color(0, 102, 255));
        botonFacturafísica.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonFacturafísica.setForeground(new java.awt.Color(255, 255, 255));
        botonFacturafísica.setText("(Generar factura física TXT)");
        botonFacturafísica.addActionListener(this::botonFacturafísicaActionPerformed);

        labelD.setText("ID del cliente: ");

        textoID.addActionListener(this::textoIDActionPerformed);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("---------------------------------------------------------------------------------------------------------------------------------------------------------");

        botonAgregar.setBackground(new java.awt.Color(0, 102, 255));
        botonAgregar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonAgregar.setForeground(new java.awt.Color(255, 255, 255));
        botonAgregar.setText("(Agregar +)");
        botonAgregar.addActionListener(this::botonAgregarActionPerformed);

        labelProductos.setText("PRODUCTOS: ");

        JTablaProductos.setAutoCreateRowSorter(true);
        JTablaProductos.setBackground(new java.awt.Color(204, 255, 255));
        JTablaProductos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JTablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Precio", "Cantidad", "Subtotal"
            }
        ));
        jScrollPane1.setViewportView(JTablaProductos);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("---------------------------------------------------------------------------------------------------------------------------------------------------------");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("---------------------------------------------------------------------------------------------------------------------------------------------------------");

        labelTotal.setText("TOTAL:");

        labelD1.setText("ID del producto: ");

        labelD2.setText("Cantidad: ");

        textoIDProducto.addActionListener(this::textoIDProductoActionPerformed);

        textocantidad.addActionListener(this::textocantidadActionPerformed);

        labelFecha.setText("FECHA:");

        botonVolver.setBackground(new java.awt.Color(0, 102, 255));
        botonVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonVolver.setForeground(new java.awt.Color(255, 255, 255));
        botonVolver.setText("Volver");
        botonVolver.addActionListener(this::botonVolverActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelD1)
                    .addComponent(labelD)
                    .addComponent(labelD2))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textoIDProducto)
                    .addComponent(textoID)
                    .addComponent(textocantidad))
                .addGap(71, 71, 71)
                .addComponent(botonAgregar)
                .addGap(176, 176, 176))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(botonVolver)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonFacturafísica)
                        .addGap(49, 49, 49))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelFecha)
                            .addComponent(labelTotal)
                            .addComponent(labelProductos)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 926, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 926, Short.MAX_VALUE)
                                    .addComponent(jScrollPane1))
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 926, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 35, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelD))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoIDProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelD1)
                    .addComponent(botonAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelD2)
                    .addComponent(textocantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(labelFecha)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelProductos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(labelTotal)
                .addGap(121, 121, 121)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonFacturafísica, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonFacturafísicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonFacturafísicaActionPerformed
        if(cliente == null){
            JOptionPane.showMessageDialog(this, "Debe seleccionar un cliente");
            return;
        }
        if (detalles.isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe agregar al menos un producto");
            return;
        }
        
        Factura factura = sistema.crearFactura(cliente, detalles);
        factura.setIdFactura(contadorFacturas++);
        
        FacturaFisica facturafisica = new FacturaFisica();
        facturafisica.setFactura(factura);
        facturafisica.generarTXT();
        JOptionPane.showMessageDialog(this, "Factura generada correctamente");
        detalles.clear();
        
        DefaultTableModel modelo =(DefaultTableModel)JTablaProductos.getModel();
        modelo.setRowCount(0);
        labelTotal.setText("TOTAL:");
    }//GEN-LAST:event_botonFacturafísicaActionPerformed

    private void textoIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoIDActionPerformed

    }//GEN-LAST:event_textoIDActionPerformed

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        int idCliente=Integer.parseInt(textoID.getText());
        cliente = sistema.buscarCliente(idCliente);
        
        int idProducto = Integer.parseInt(textoIDProducto.getText());
        Producto producto = sistema.buscarProducto(idProducto);
        
        int cantidad = Integer.parseInt(textocantidad.getText());
        
        if(cliente == null){
            JOptionPane.showMessageDialog(this, "Cliente no encontrado");
            return;
        }
        
        if(producto == null){
            JOptionPane.showMessageDialog(this, "Producto no encontrado");
            return;
        }
        
        DetalleFactura detalle = new DetalleFactura();
        detalle.setProducto(producto);
        detalle.setCantidad(cantidad);
        detalle.calcularSubtotal();
        detalles.add(detalle);
        
        DefaultTableModel modelo = (DefaultTableModel)JTablaProductos.getModel();
        Object[] fila = {
            producto.getIdProducto(),
            producto.getNombreProducto(),
            producto.getPrecio(),
            cantidad,
            detalle.getSubTotal()
        };
        modelo.addRow(fila);
        
        double total= 0;
        for (DetalleFactura d : detalles){
            total += d.getSubTotal();
        }
        labelTotal.setText("TOTAL: ₡"+total);
        textoIDProducto.setText("");
        textocantidad.setText("");
    }//GEN-LAST:event_botonAgregarActionPerformed

    private void textoIDProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoIDProductoActionPerformed
       
    }//GEN-LAST:event_textoIDProductoActionPerformed

    private void textocantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textocantidadActionPerformed
        
    }//GEN-LAST:event_textocantidadActionPerformed

    private void botonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverActionPerformed
        new MenúPrincipal(usuario,sistema).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonVolverActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new CrearFactura("Admin", new Sistema()).setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable JTablaProductos;
    private javax.swing.JButton botonAgregar;
    private javax.swing.JButton botonFacturafísica;
    private javax.swing.JButton botonVolver;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelD;
    private javax.swing.JLabel labelD1;
    private javax.swing.JLabel labelD2;
    private javax.swing.JLabel labelFecha;
    private javax.swing.JLabel labelProductos;
    private javax.swing.JLabel labelTitulo1;
    private javax.swing.JLabel labelTotal;
    private javax.swing.JTextField textoID;
    private javax.swing.JTextField textoIDProducto;
    private javax.swing.JTextField textocantidad;
    // End of variables declaration//GEN-END:variables
}
