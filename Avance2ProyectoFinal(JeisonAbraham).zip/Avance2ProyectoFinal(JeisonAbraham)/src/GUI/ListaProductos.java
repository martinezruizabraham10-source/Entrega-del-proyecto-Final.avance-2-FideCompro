
package GUI;
import Clases.Sistema;
import Clases.Producto;
import javax.swing.table.DefaultTableModel;

public final class ListaProductos extends javax.swing.JFrame {
    private final String usuario;
    private final Sistema sistema;
   
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ListaProductos.class.getName());


    public ListaProductos(String usuario, Sistema sistema) {
        initComponents();
        
        this.usuario = usuario;
        this.sistema = sistema;
        cargarProductos();
    }

     public void cargarProductos(){
        DefaultTableModel modelo =(DefaultTableModel)JTablaProductos.getModel();
        modelo.setRowCount(0);
        for( Producto producto : sistema.getInventario().getProductos()){
            Object[]fila={
                producto.getIdProducto(),
                producto.getNombreProducto(),
                producto.getTipo(),
                producto.getPrecio(),
                producto.getCantidad()
            };
            modelo.addRow(fila);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        labelTitulo = new javax.swing.JLabel();
        botonSalirAlMenu = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        botonBuscarProducto = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTablaProductos = new javax.swing.JTable();
        botonAgregarProducto = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(0, 102, 255));

        labelTitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelTitulo.setForeground(new java.awt.Color(255, 255, 255));
        labelTitulo.setText("Inventario de productos");

        botonSalirAlMenu.setBackground(new java.awt.Color(0, 102, 255));
        botonSalirAlMenu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonSalirAlMenu.setForeground(new java.awt.Color(255, 255, 255));
        botonSalirAlMenu.setText("Salir al menú");
        botonSalirAlMenu.addActionListener(this::botonSalirAlMenuActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelTitulo)
                .addGap(33, 33, 33)
                .addComponent(botonSalirAlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelTitulo)
                    .addComponent(botonSalirAlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        jPanel3.setBackground(new java.awt.Color(0, 102, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 553, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );

        botonBuscarProducto.setBackground(new java.awt.Color(0, 102, 255));
        botonBuscarProducto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonBuscarProducto.setForeground(new java.awt.Color(255, 255, 255));
        botonBuscarProducto.setText("[Buscar producto]");
        botonBuscarProducto.addActionListener(this::botonBuscarProductoActionPerformed);

        JTablaProductos.setAutoCreateRowSorter(true);
        JTablaProductos.setBackground(new java.awt.Color(204, 255, 255));
        JTablaProductos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JTablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Tipo", "Precio", "Cantidad"
            }
        ));
        jScrollPane1.setViewportView(JTablaProductos);

        botonAgregarProducto.setBackground(new java.awt.Color(0, 102, 255));
        botonAgregarProducto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonAgregarProducto.setForeground(new java.awt.Color(255, 255, 255));
        botonAgregarProducto.setText("[Agregar producto]");
        botonAgregarProducto.addActionListener(this::botonAgregarProductoActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonAgregarProducto)
                .addGap(30, 30, 30)
                .addComponent(botonBuscarProducto)
                .addGap(176, 176, 176))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonBuscarProducto)
                    .addComponent(botonAgregarProducto))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirAlMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirAlMenuActionPerformed
        new MenúPrincipal(usuario,sistema).setVisible(true);
        this.dispose();

    }//GEN-LAST:event_botonSalirAlMenuActionPerformed

    private void botonBuscarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarProductoActionPerformed
        new BuscarProducto(usuario,sistema).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonBuscarProductoActionPerformed

    private void botonAgregarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarProductoActionPerformed
        new AgregarProductos(usuario, sistema).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonAgregarProductoActionPerformed


    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> new ListaProductos("Admin", new Sistema()).setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable JTablaProductos;
    private javax.swing.JButton botonAgregarProducto;
    private javax.swing.JButton botonBuscarProducto;
    private javax.swing.JButton botonSalirAlMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelTitulo;
    // End of variables declaration//GEN-END:variables
}
