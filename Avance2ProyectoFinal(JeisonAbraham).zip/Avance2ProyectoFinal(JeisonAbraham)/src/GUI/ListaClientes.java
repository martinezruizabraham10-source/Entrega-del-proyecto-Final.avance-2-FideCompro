
package GUI;
import Clases.Sistema;
import Clases.Cliente;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Jeison Abraham Martínez Ruíz
 */
public final class ListaClientes extends javax.swing.JFrame {
    private final String usuario;
    private final Sistema sistema;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ListaClientes.class.getName());



    public ListaClientes(String usuario, Sistema sistema) {
        initComponents();
        
        this.usuario= usuario;
        this.sistema= sistema;
        
        cargarClientes();
    }
    public void cargarClientes(){
        DefaultTableModel modelo =(DefaultTableModel)JTabla.getModel();
        modelo.setRowCount(0);
        for( Cliente cliente : sistema.getListaClientes()){
            Object[]fila={
                cliente.getIdCliente(),
                cliente.getNombre(),
                cliente.getCedula(),
                cliente.getDireccion()   
            };
            modelo.addRow(fila);
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        labelTitulo = new javax.swing.JLabel();
        botonSalirAlMenu = new javax.swing.JButton();
        botonAgregarCliente = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTabla = new javax.swing.JTable();
        botonBuscarCliente = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(0, 102, 255));

        labelTitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelTitulo.setForeground(new java.awt.Color(255, 255, 255));
        labelTitulo.setText("Gestión de clientes");

        botonSalirAlMenu.setBackground(new java.awt.Color(0, 102, 255));
        botonSalirAlMenu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonSalirAlMenu.setForeground(new java.awt.Color(255, 255, 255));
        botonSalirAlMenu.setText("Salir al menú");
        botonSalirAlMenu.addActionListener(this::botonSalirAlMenuActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(labelTitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonSalirAlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelTitulo)
                    .addComponent(botonSalirAlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        botonAgregarCliente.setBackground(new java.awt.Color(0, 102, 255));
        botonAgregarCliente.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonAgregarCliente.setForeground(new java.awt.Color(255, 255, 255));
        botonAgregarCliente.setText("[Agregar cliente]");
        botonAgregarCliente.addActionListener(this::botonAgregarClienteActionPerformed);

        JTabla.setAutoCreateRowSorter(true);
        JTabla.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Cédula", "Dirección"
            }
        ));
        jScrollPane1.setViewportView(JTabla);

        botonBuscarCliente.setBackground(new java.awt.Color(0, 102, 255));
        botonBuscarCliente.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonBuscarCliente.setForeground(new java.awt.Color(255, 255, 255));
        botonBuscarCliente.setText("[Buscar cliente]");
        botonBuscarCliente.addActionListener(this::botonBuscarClienteActionPerformed);

        jPanel3.setBackground(new java.awt.Color(0, 102, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(botonAgregarCliente)
                .addGap(38, 38, 38)
                .addComponent(botonBuscarCliente)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAgregarCliente)
                    .addComponent(botonBuscarCliente))
                .addGap(38, 38, 38)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonSalirAlMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirAlMenuActionPerformed
       new MenúPrincipal(usuario,sistema).setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_botonSalirAlMenuActionPerformed

    private void botonAgregarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarClienteActionPerformed
        new AgregarCliente(usuario, sistema).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonAgregarClienteActionPerformed

    private void botonBuscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarClienteActionPerformed
        new BuscarCliente(usuario,sistema).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonBuscarClienteActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> new ListaClientes("Admin", new Sistema()).setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable JTabla;
    private javax.swing.JButton botonAgregarCliente;
    private javax.swing.JButton botonBuscarCliente;
    private javax.swing.JButton botonSalirAlMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelTitulo;
    // End of variables declaration//GEN-END:variables
}
